#!/bin/bash
 
#root checking 
FIRST=$(timedatectl | grep Local | awk '{print $5}' | sed 's/://g')
function CHECKIFROOT(){
if [ "$(whoami)" == "root" ]
then echo "You are  root"
else echo "enter as a root " && exit
fi
}
CHECKIFROOT

        #check if the file exists:
	function IFEXIST(){
	echo "write the file name:"
	read ANSWER
	RESULT=$(find /-name $ANSWER 2>/dev/null)
	if [ -z $RESULT ] 
	then echo ">>-file not exsist-<< " && exit
	else echo "i found the file "
	fi
	}
	IFEXIST

# installing relevant:
function FULLTOOL(){
sudo apt install bulk-extractor
sudo apt-get --assume-yes install binwalk
sudo apt-get --assume-yes install foremost
sudo apt-get --assume-yes install strings
sudo apt-get --assume-yes install wget
}
FULLTOOL	

        #  create  directory and find where it  saved:
	cd /home/kali/Desktop
	mkdir Datacarving
	mkdir Datacarving/Vol
	cd /home/kali/Desktop/Datacarving/Vol
	wget http://downloads.volatilityfoundation.org/releases/2.6/volatility_2.6_lin64_standalone.zip && sudo chmod 777 -R volatility_2.6_lin64_standalone.zip 
	sudo unzip volatility_2.6_lin64_standalone.zip && chmod 777 -R volatility_2.6_lin64_standalone && cd volatility_2.6_lin64_standalone && mv volatility_2.6_lin64_standalone vol 
	cd /home/kali/Desktop
	mkdir Datacarving/STRINGS
	mkdir Datacarving/BINWALK
	binwalk $RESULT >> Datacarving/BINWALK/Binwalk
	foremost -i $RESULT -t all -o Datacarving/Foremost 
	strings $RESULT >> Datacarving/STRINGS/Strings
	bulk_extractor $RESULT -o Datacarving/Bulkoutput 
	sudo chmod 777 -R Datacarving
	cp $RESULT /home/kali/Desktop/Datacarving/Vol/volatility_2.6_lin64_standalone/$ANSWER
	echo 
	echo
	if [ -e /home/kali/Desktop/Datacarving/Bulkoutput/packets.pcap ]
	then echo "the file has been saved "
	fi
	
	
#Validate the input file
function VOLCHK(){
VOLCHECK=$(/home/kali/Desktop/Datacarving/Vol/volatility_2.6_lin64_standalone/./vol -f $ANSWER imageinfo | grep -i suggested | awk '{print $4}' | awk -F , '{print $1}')
if [ "$VOLCHECK" == "No" ]
then echo "can't analyzed by volatility"
else echo "can analyzed by volatility," 
RUN
fi
}
        #show  running processes
	mkdir /home/kali/Desktop/Datacarving/Reports
	function RUN(){
	COMMAND='pslist pstree psscan'
	for i in $COMMAND
	do /home/kali/Desktop/Datacarving/Vol/volatility_2.6_lin64_standalone/./vol -f $ANSWER --profile $VOLCHECK $i >> /home/kali/Desktop/Datacarving/Reports/process && sudo chmod 777 -R /home/kali/Desktop/Datacarving/Reports/process
	done	
	
#Display network:
COMMAND='sockets connscan sockscan netscan connection'
for i in $COMMAND
do /home/kali/Desktop/Datacarving/Vol/volatility_2.6_lin64_standalone/./vol -f $ANSWER --profile $VOLCHECK $i >> /home/kali/Desktop/Datacarving/Reports/network && sudo chmod 777 -R /home/kali/Desktop/Datacarving/Reports/network
done
	
        #Display registry:
	COMMAND='hivescan hivelist lsadump shellbags'
	for i in $COMMAND
	do /home/kali/Desktop/Datacarving/Vol/volatility_2.6_lin64_standalone/./vol -f $ANSWER --profile $VOLCHECK $i >> /home/kali/Desktop/Datacarving/Reports/registry && sudo chmod 777 -R /home/kali/Desktop/Datacarving/Reports/registry
	done
	}
	VOLCHK

#Results:
ls Datacarving/Bulkoutput >> /home/kali/Desktop/Datacarving/report
sudo chmod 777 -R /home/kali/Desktop/Datacarving/report
echo "the files extracted " >> /home/kali/Desktop/Datacarving/report && ls /home/kali/Desktop/Datacarving/Bulkoutput | wc -l >> /home/kali/Desktop/Datacarving/report 
echo  "the  file has been saved in the directory"
LAST=$(timedatectl | grep Local | awk '{print $5}' | sed 's/://g')
TIME=$(expr $LAST - $FIRST)
echo "thetime it was taken to analyze " >> /home/kali/Desktop/Datacarving/report 
echo $TIME >> /home/kali/Desktop/Datacarving/report

#compress  in zip file and show where it's saved
cd /home/kali/Desktop
zip -qr Datacarving.zip Datacarving && sudo chmod 777 -R Datacarving.zip
echo "the zipped directory has been saved "
